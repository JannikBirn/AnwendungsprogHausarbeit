﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace De.HsFlensburg.ClientApp012.Business.Model.BusinessObjects
{
    public class Client
    {
        public int Id { get; set; }
        public String Name { get; set; }
    }
}
