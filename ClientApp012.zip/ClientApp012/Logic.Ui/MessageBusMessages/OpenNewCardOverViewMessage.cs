﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace De.HsFlensburg.ClientApp012.Logic.Ui.MessageBusMessages
{
    //Wird benötigt, um ein neues Fenster zu öffnen
    public class OpenNewCardOverViewMessage
    {
    }
}
