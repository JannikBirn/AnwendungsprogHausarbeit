﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;

namespace De.HsFlensburg.ClientApp012.Logic.Ui.MessageBusMessages
{
    public class SetPrintPreviewMessage
    {
        public FixedDocumentSequence FixedDocumentSequence { get; set; }
    }
}
